export default function Home() {
  return <p>Welcome to Gitanjali professional SPA 🚀</p>
}
