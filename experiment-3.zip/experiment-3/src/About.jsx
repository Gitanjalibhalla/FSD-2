export default function About() {
  return <p>This app is used to demonstrates routing using React Router made by Gitanjali.</p>
}
