export default function Contact() {
  return <p>Contact: Gitanjali@gmail.com</p>
}
